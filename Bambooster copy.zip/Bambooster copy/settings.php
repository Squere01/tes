<?php

$Firstname = $_POST['Firstname'];
$Lastname = $_POST['Lastname'];
$email = $_POST['email'];
$Subject = $_POST['Subject'];
$phone = $_POST['phone'];
$Description = $_POST['Description'];

use PHPMailer\PHPMailer\PHPMailer;

require 'PHPMailer-master\src\PHPMailer.php';
require 'PHPMailer-master\src\SMTP.php';

$mail = new PHPMailer;

$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'indonsiabambooster@gmail.com';
$mail->Password = 'ofns awbh pwjr oopr';
$mail->SMTPSecure = 'tls';
$mail->Port = 587;

$mail->setFrom('indonsiabmabooster@gmail.com');
$mail->addAddress($email);
$mail->Subject = $Subject;
$mail->Body = $Description;

if (!$mail->send()) {
    echo "Mailer error: " . $mail->ErrorInfo;
} else {
    echo "Message has been sent succesfully";
}