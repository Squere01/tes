<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="contact.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title>Document</title>
</head>
<body>
    <nav class="navbar">
        <div class="isinav">
            <a href="index.html"><img src="Asset/Logo.jpeg" alt=""></a>
        </div>

        <div class="isi2nav">
            <div class="box-isi2nav">
                <a href="index.html">Home</a>
                <a href="learn.html">Our Product</a>
                <a href="shop.html">Shop</a>
            </div>

            <div class="box2-isi2nav">
                <a href="wesmart.html">About Us</span></a>
            <a href="contact.html"  style="font-weight: 500; color: black;" class="lagi2bang">Contact Us</a>
            </div>
            </a>
        </div>

    </nav>

    <section class="header">
        <p id="header-text">Need Helps ?</p>
    </section>


    <!-- BATASAN NAVBAR BATASAN NAVBAR BATASAN NAVBAR -->
    <!-- BATASAN NAVBAR BATASAN NAVBAR BATASAN NAVBAR -->

    <!-- BATASAN CONTENT 1 BATASAN CONTENT 1 BATASAN CONTENT ! -->
    <!-- BATASAN CONTENT 1 BATASAN CONTENT 1 BATASAN CONTENT ! -->

    <div class="content2">
            <form action="settings.php" method="post" class="content2-kotak">
            <div class="wrapper1-content2">
                <input type="text" placeholder="First Name" name="Firstname" required >
                <input type="text" placeholder="Last Name" name="Lastname" required>
            </div>

            <div class="wrapper1-content2">
                <input type="text" placeholder="Email" name="email" required>
                <input type="text" placeholder="Subject" name="subject" required>
            </div>

            <div class="wrapper3-content2">
                <input type="text" placeholder="Phone" name="phone" required>
            </div>

            <div class="wrapper2-content2">
                <textarea name="" id="" cols="30" rows="10" placeholder="Description" name="Description" required></textarea>
            </div>

            <button>Submit</button>
        </form>
    </div>

    <div class="blankpage">

    </div>

    <footer class="footer1">
        <div class="inside1">
            <h1>Bambooster contact<br>details</h1>

            <div class="wrapper-footer1">
                <div class="inside-wrapper1">
                    <p style="font-weight: bold;">Address:</p>
                    <p style="margin-top: 1vh; color: rgba(255, 255, 255, 0.534);">Jl. Kamboja No.4, <br>Dangin Puri Kangin, <br>Denpasar Utara, Bali<br>Indonesia</p>
                </div>

                <div class="inside-wrapper2">
                    <p>Mail and Telephone:</p>
                    <p style="margin-top: 1vh; color: rgba(255, 255, 255, 0.534);">indonsiabambooster@gmail.com</p>
                    <p style="color: rgba(255, 255, 255, 0.534);">+62 821-159-811-20</p>
                    <p style="color: rgba(255, 255, 255, 0.534);">+62 812-372-359-60</p>
                </div>
            </div>
        </div>
    </footer>

    <footer class="footer2">

    </footer>

    <footer class="footer3">
        <div class="box-footer3">
            <img src="Asset/Untitled-4-removebg-preview-4.png" alt="">
        </div>
    </footer>

    <footer class="footer4">
        <div class="box-footer4">
            <p>We are committed to providing quality and environmentally <br>friendly batteries from waste batteries.</p>
            <button>Contact Us</button>
        </div>
    </footer>

    <footer class="footer5">
        <div class="box-footer5">
         <div class="wrap-footer5">
            <p>About</p>
            <p>Memberships</p>
            <p>Feedback</p>
            <p>Popular Page</p>
         </div>

         <div class="wrap2-footer5">
            <p>News</p>
            <p>Who ?</p>
            <a href="https://sman1dps.sch.id/" target="_blank"><p>Connections</p></a>
         </div>
        </div>
    </footer>

    <footer class="footer6">
        <div class="box-footer6">   
            <i class="fa-brands fa-facebook-f"></i>
            <i class="fa-brands fa-instagram"></i>
            <i class="fa-brands fa-youtube"></i>
            <i class="fa-brands fa-x-twitter"></i>
        </div>
    </footer>

    <footer class="footer-7">
        <hr style="border-bottom: solid white; border-radius: 1vh;">
    </footer>

    <footer class="footer-8">
        <div class="box-footer8">
            <div class="wrap-footer8">
                <i class="fa-solid fa-location-dot"></i>
                <p>Bali, Indonesia</p>
            </div>

            <img src="Asset/Babooz-removebg-preview copy.png" alt="">

            <p>© 2023 Bambooster, Inc. All Rights Reserved</p>
        </div>
    </footer>

    <footer class="footer-9">

    </footer>




</body>
</html>
